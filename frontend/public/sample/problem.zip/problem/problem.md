## Problem Statement

Sum two numbers a and b

## Input

Two integers a and b, where 1 ≤ a, b ≤ 10^9

## Output

The sum of a and b

## Example

**Input:**

```plaintext
1 2
```

**Output:**

```plaintext
3
```
